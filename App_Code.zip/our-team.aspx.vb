﻿
Partial Class our_team
    Inherits System.Web.UI.Page

End Class
